import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
  name: { type: String, required: true },
  address: { type: String, required: true },
  products: { type: Array, required: true }, // Lista de productos pedidos
  date: { type: Date, default: Date.now },  // Fecha del pedido
});

export default mongoose.model("Order", orderSchema);
