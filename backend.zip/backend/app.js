import express from 'express';
import mongoose from 'mongoose';
import path from 'path';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import adminRoutes from './routes/admin.js';
import User from './models/User.js';
import orderRoutes from "./routes/order.js";



dotenv.config();

const app = express();

// Configuración básica
app.set('view engine', 'pug');
app.set('views', path.join(path.resolve(), 'backend/views'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Rutas
app.use('/admin', adminRoutes);
app.use("/api/orders", orderRoutes);


// Conexión a MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('Conexión exitosa a MongoDB');
    console.log(`Base de datos en uso: ${mongoose.connection.db.databaseName}`);
    initializeSuperuser();
  })
  .catch((err) => {
    console.error('Error conectando a MongoDB:', err);
  });



// Función para crear el superusuario Paula
const initializeSuperuser = async () => {
  try {
    const existingUser = await User.findOne({ username: 'Paula' });
    if (!existingUser) {
      const superuser = new User({
        username: 'Paula',
        password: '123456789', // Cambia esta contraseña
        role: 'admin',
      });
      await superuser.save();
      console.log('Superusuario Paula creado con éxito.');
    } else {
      console.log('El superusuario Paula ya existe.');
    }
  } catch (err) {
    console.error('Error al crear el superusuario Paula:', err);
  }
};

// Iniciar el servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
